package TESTIRANJE;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

class tests {
	static WebDriver webDriver;
	static String BaseUrl;


	@BeforeAll
			static void setUpBeforeClass() throws Exception {
			System.setProperty("webdriver.chrome.driver","C:\\Users\\Korisnik\\Desktop\\chrom\\chromedriver.exe");
			webDriver= new ChromeDriver();
			BaseUrl="https://www.fashionandfriends.com/ba/";
			webDriver.manage().window().maximize();
			
		}
	

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		webDriver.close();
	}

@Test

	void test1TitleiClick() throws InterruptedException {
		webDriver.get("https://www.fashionandfriends.com/ba/");
		WebElement muskarci=webDriver.findElement(By.xpath("//*[@id=\"ui-id-8\"]/span[1]"));
		Thread.sleep(2000);
		muskarci.click();
		Thread.sleep(2000);
		String title="Najnovije mu�ke kolekcije | Fashion&Friends";
		assertEquals(title,webDriver.getTitle());
		Thread.sleep(2000);
		Thread.sleep(2000);
		WebElement zene=webDriver.findElement(By.xpath("//*[@id=\"ui-id-2\"]/span[1]"));
		zene.click();
		webDriver.getCurrentUrl();
		assertEquals("Najnovije �enske Kolekcije | Fashion&Friends",webDriver.getTitle());
		Thread.sleep(2000);
		WebElement djeca=webDriver.findElement(By.xpath("//*[@id=\"ui-id-14\"]"));
		Thread.sleep(3000);
		djeca.click();
		Thread.sleep(2000);
		webDriver.getCurrentUrl();
		assertEquals("Djeca",webDriver.getTitle());
		
	}




	
	  @Test
	 
	void test2Instagramredirect() throws InterruptedException {
		webDriver.get("https://l.instagram.com/?u=http%3A%2F%2Fbit.ly%2FFF_online_shop&e=AT2IgHRyg4ghPrTeD4xw6qaXQQulgwflNv-X8EOw0BsNUzBQRfudDfvWdBCSwF23G3nSdYlbiLYxoH_PVtlh4B3e2rAvBRMo&s=1");
		Thread.sleep(2000);
		String a=webDriver.getCurrentUrl();
		assertEquals("https://www.fashionandfriends.com/ba/?utm_source=instagram&utm_medium=social&utm_campaign=ff_bih_homepage&utm_content=link_in_bio",a);
		Thread.sleep(3000);
		
	}
	
	@Test
		void test3Sourca(){
		webDriver.get("https://www.fashionandfriends.com/ba/");
		String pageSource=webDriver.getPageSource();
		assertTrue(pageSource.contains("�ene"));
		assertFalse(pageSource.contains("Nemanja Bilbija je najbolji strijelac PL"));
		
	}

	@Test
	void test4Login () throws InterruptedException {
			webDriver.get(BaseUrl);
			Thread.sleep(2000);
			WebElement Profile=webDriver.findElement(By.xpath("//*[@id=\"html-body\"]/main/div/header/div[2]/div[1]/div/div/div[3]/div/div[1]/button"));
			Thread.sleep(2000);
			Profile.click();
			Thread.sleep(2000);
			WebElement Login=webDriver.findElement(By.xpath("//*[@id=\"html-body\"]/main/div/header/div[2]/div[1]/div/div/div[3]/div/div[1]/div/ul/li[5]/a"));
			Thread.sleep(2000);
			Login.click();
			Thread.sleep(2000);
			WebElement Email=webDriver.findElement(By.xpath("//*[@id=\"email\"]"));
			Thread.sleep(2000);
			Email.sendKeys("fadi.egho@stu.ibu.edu.ba");
			Thread.sleep(2000);
			WebElement Password=webDriver.findElement(By.xpath("//*[@id=\"pass\"]"));
			Thread.sleep(2000);
			Password.sendKeys("Burch1921");
			Thread.sleep(2000);
			WebElement LoginButton=webDriver.findElement(By.xpath("//*[@id=\"send2\"]/span"));
			LoginButton.click();
			Thread.sleep(5000);
}


	@Test
	void test5LoginFailed () throws InterruptedException {
			webDriver.get(BaseUrl);
			Thread.sleep(2000);
			WebElement Profile=webDriver.findElement(By.xpath("//*[@id=\"html-body\"]/main/div/header/div[2]/div[1]/div/div/div[3]/div/div[1]/button"));
			Thread.sleep(2000);
			Profile.click();
			Thread.sleep(2000);
			WebElement Login=webDriver.findElement(By.xpath("//*[@id=\"html-body\"]/main/div/header/div[2]/div[1]/div/div/div[3]/div/div[1]/div/ul/li[5]/a"));
			Thread.sleep(2000);
			Login.click();
			Thread.sleep(2000);
			WebElement Email=webDriver.findElement(By.xpath("//*[@id=\"email\"]"));
			Thread.sleep(2000);
			Email.sendKeys("fadi.egho@stu.ibu.edu.ba");
			Thread.sleep(2000);
			WebElement Password=webDriver.findElement(By.xpath("//*[@id=\"pass\"]"));
			Thread.sleep(2000);
			Password.sendKeys("Burch1921sda");
			Thread.sleep(2000);
			WebElement LoginButton=webDriver.findElement(By.xpath("//*[@id=\"send2\"]/span"));
			LoginButton.click();
			Thread.sleep(3000);
			WebElement Failmess=webDriver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[1]/div[2]/div[1]/div/div"));
			Thread.sleep(2000);
			assertEquals("Prijava na nalog nije ispravna ili je Va� nalog privremeno onemogu�en. Molimo sa�ekajte i poku�ajte ponovo kasnije.",Failmess.getText());
			Thread.sleep(2000);
	}

	@Test
	
	void testSearch6() throws InterruptedException {
		webDriver.get(BaseUrl);
		Thread.sleep(2000);
		WebElement Search=webDriver.findElement(By.xpath("//*[@id=\"html-body\"]/main/div/header/div[2]/div[2]/div/div/div[3]/div/div/div[2]/button/i"));
		Search.click();
		WebElement Input=webDriver.findElement(By.name("q"));
		Thread.sleep(2000);
		Input.sendKeys("North Face",Keys.ENTER);
		Thread.sleep(2000);
		WebElement Search1=webDriver.findElement(By.xpath("//*[@id=\"html-body\"]/main/div/header/div[2]/div[2]/div/div/div[3]/div/div/div[2]/button/i"));
		Search1.click();
		WebElement Input1=webDriver.findElement(By.name("q"));
		Thread.sleep(2000);
		Input1.sendKeys("Lyle and Scot",Keys.ENTER);
		Thread.sleep(3000);
		WebElement Search2=webDriver.findElement(By.xpath("//*[@id=\"html-body\"]/main/div/header/div[2]/div[2]/div/div/div[3]/div/div/div[2]/button/i"));
		Search2.click();
		WebElement Input2=webDriver.findElement(By.name("q"));
		Thread.sleep(2000);
		Input2.sendKeys("Tommy Hilfiger",Keys.ENTER);
		Thread.sleep(4000);

	}

	@Test
		void test7zapatmicheck () throws InterruptedException {
			webDriver.get(BaseUrl);
			Thread.sleep(2000);
			WebElement Profile=webDriver.findElement(By.xpath("//*[@id=\"html-body\"]/main/div/header/div[2]/div[1]/div/div/div[3]/div/div[1]/button"));
			Thread.sleep(2000);
			Profile.click();
			Thread.sleep(2000);
			WebElement Login=webDriver.findElement(By.xpath("//*[@id=\"html-body\"]/main/div/header/div[2]/div[1]/div/div/div[3]/div/div[1]/div/ul/li[5]/a"));
			Thread.sleep(2000);
			Login.click();
			Thread.sleep(2000);
			WebElement Email=webDriver.findElement(By.xpath("//*[@id=\"email\"]"));
			Thread.sleep(2000);
			Email.sendKeys("fadi.egho@stu.ibu.edu.ba");
			Thread.sleep(2000);
			WebElement Password=webDriver.findElement(By.xpath("//*[@id=\"pass\"]"));
			Thread.sleep(2000);
			Password.sendKeys("Burch1921");
			Thread.sleep(2000);
			WebElement zapamtime=webDriver.findElement(By.xpath("/html/body/main/div/section/div[2]/div/div[5]/div[1]/div/div[2]/form/fieldset/div[4]/input"));
			zapamtime.click();
			Thread.sleep(4000);
			assertTrue(zapamtime.isSelected());
			Thread.sleep(2000);
			WebElement zapamtime2=webDriver.findElement(By.xpath("/html/body/main/div/section/div[2]/div/div[5]/div[1]/div/div[2]/form/fieldset/div[4]/input"));
			zapamtime2.click();
			Thread.sleep(2000);
			assertFalse(zapamtime2.isSelected());
			Thread.sleep(2000);
		}

	

	@Test
	void test8Size() throws InterruptedException {
		webDriver.get("https://www.fashionandfriends.com/ba/muskarci/");
		Thread.sleep(5000);
		WebElement Odjeca=webDriver.findElement(By.xpath("//*[@id=\"ui-id-9\"]/div/div/div/div/div/div[2]/a/span[2]"));
		Thread.sleep(2000);
		Odjeca.click();
		Thread.sleep(4000);
		WebElement majica=webDriver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div[1]/div[5]/ul/li[1]/div[1]/a"));
		majica.click();
		Thread.sleep(4000);
		WebElement sizeL=webDriver.findElement(By.xpath("//*[@id=\"option-label-size-242-item-5508\"]"));
		sizeL.click();
		WebElement size=webDriver.findElement(By.xpath("//*[@id=\"product-options-wrapper\"]/div/div/div/div[1]/span[2]"));
		assertEquals("L",size.getText());
		Thread.sleep(4000);
		WebElement sizeL2=webDriver.findElement(By.xpath("//*[@id=\"option-label-size-242-item-5508\"]"));
		sizeL2.click();
		Thread.sleep(4000);
		assertEquals("",size.getText());
		
	}

	@Test
	void test9cartprice() throws InterruptedException {
		webDriver.get("https://www.fashionandfriends.com/ba/muskarci/odjeca/");
		Thread.sleep(5000);
		WebElement ckkup=webDriver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div[1]/div[5]/ul/li[3]/div[1]/a"));
		ckkup.click();
		Thread.sleep(3000);
		WebElement size=webDriver.findElement(By.xpath("/html/body/main/div/section/div[2]/div/div[2]/div[2]/div/div/div[4]/form/div[1]/div/div/div/div[1]/div[1]/div[3]"));
		size.click();
		Thread.sleep(3000);
		WebElement dodajteukorpu=webDriver.findElement(By.xpath("//*[@id=\"product-addtocart-button\"]"));
		dodajteukorpu.click();
		Thread.sleep(3000);
		webDriver.navigate().to("https://www.fashionandfriends.com/ba/muskarci/odjeca/");
		Thread.sleep(3000);
		WebElement bossmajica=webDriver.findElement(By.xpath("/html/body/main/div/section/div[3]/div[1]/div[5]/ul/li[6]/div[1]/a"));
		bossmajica.click();
		Thread.sleep(3000);
		WebElement sizeL=webDriver.findElement(By.xpath("//*[@id=\"option-label-size-242-item-5508\"]"));
		sizeL.click();
		Thread.sleep(3000);
		WebElement cartbutton=webDriver.findElement(By.xpath("//*[@id=\"product-addtocart-button\"]"));
		cartbutton.click();
		Thread.sleep(3000);
		WebElement cart=webDriver.findElement(By.xpath("//*[@id=\"html-body\"]/main/div/header/div[2]/div[1]/div/div/div[3]/div/div[3]/a"));
		cart.click();
		Thread.sleep(3000);
		WebElement korpa=webDriver.findElement(By.xpath("//*[@id=\"minicart-content-wrapper\"]/div/div[2]/div[2]/div[1]/a"));
		korpa.click();
		Thread.sleep(3000);
		WebElement price=webDriver.findElement(By.xpath("//*[@id=\"cart-totals\"]/div/table/tbody/tr[4]/td/strong/span"));
		assertEquals("244,00 KM",price.getText());
		}

	@Test 
	void testo10order() throws InterruptedException {
		webDriver.get("https://www.fashionandfriends.com/ba/muskarci/odjeca/");
		Thread.sleep(5000);
		WebElement ckkup=webDriver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div[1]/div[5]/ul/li[3]/div[1]/a"));
		ckkup.click();
		Thread.sleep(3000);
		WebElement size=webDriver.findElement(By.xpath("/html/body/main/div/section/div[2]/div/div[2]/div[2]/div/div/div[4]/form/div[1]/div/div/div/div[1]/div[1]/div[3]"));
		size.click();
		Thread.sleep(3000);
		WebElement dodajteukorpu=webDriver.findElement(By.xpath("//*[@id=\"product-addtocart-button\"]"));
		dodajteukorpu.click();
		Thread.sleep(3000);
		webDriver.navigate().to("https://www.fashionandfriends.com/ba/muskarci/odjeca/");
		Thread.sleep(3000);
		WebElement bossmajica=webDriver.findElement(By.xpath("/html/body/main/div/section/div[3]/div[1]/div[5]/ul/li[6]/div[1]/a"));
		bossmajica.click();
		Thread.sleep(3000);
		WebElement sizeL=webDriver.findElement(By.xpath("//*[@id=\"option-label-size-242-item-5508\"]"));
		sizeL.click();
		Thread.sleep(3000);
		WebElement cartbutton=webDriver.findElement(By.xpath("//*[@id=\"product-addtocart-button\"]"));
		cartbutton.click();
		Thread.sleep(3000);
		WebElement cart=webDriver.findElement(By.xpath("//*[@id=\"html-body\"]/main/div/header/div[2]/div[1]/div/div/div[3]/div/div[3]/a"));
		cart.click();
		Thread.sleep(3000);
		WebElement naplata=webDriver.findElement(By.xpath("//*[@id=\"top-cart-btn-checkout\"]"));
		naplata.click();
		Thread.sleep(3000);
		WebElement email=webDriver.findElement(By.xpath("//*[@id=\"customer-email\"]"));
		email.sendKeys("fadi.egho@stu.ibu.edu.ba");
		WebElement pass=webDriver.findElement(By.xpath("//*[@id=\"pass\"]"));
		pass.sendKeys("Burch1921",Keys.ENTER);
		Thread.sleep(10000);
		WebElement firma=webDriver.findElement(By.xpath("/html/body/main/div/section/div[2]/div/div[2]/div[4]/ul/li[1]/div[2]/form/div/div[3]/div/input"));
		firma.sendKeys("Burch");
		Thread.sleep(3000);
		WebElement adresa=webDriver.findElement(By.xpath("/html/body/main/div/section/div[2]/div/div[2]/div[4]/ul/li[1]/div[2]/form/div/fieldset/div/div[1]/div/input"));
		adresa.sendKeys("Francuske revolucije bb, Ilid�a 71210");
		Thread.sleep(3000);
		WebElement grad=webDriver.findElement(By.xpath("/html/body/main/div/section/div[2]/div/div[2]/div[4]/ul/li[1]/div[2]/form/div/div[7]/div/input"));
		grad.sendKeys("Sarajevo");
		Thread.sleep(3000);
		WebElement po�tanski=webDriver.findElement(By.xpath("/html/body/main/div/section/div[2]/div/div[2]/div[4]/ul/li[1]/div[2]/form/div/div[8]/div/input"));
		po�tanski.sendKeys("71000");
		Thread.sleep(2000);
		WebElement broj=webDriver.findElement(By.xpath("/html/body/main/div/section/div[2]/div/div[2]/div[4]/ul/li[1]/div[2]/form/div/div[9]/div/input"));
		broj.sendKeys("033 944-400");
		Thread.sleep(5000);
		
	
	
	

	
	
}}








